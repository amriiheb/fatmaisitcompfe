module.exports = (app) => {
    const facture = require('../controllers/mail.controller');

    app.post('/send',
        facture.send

    );

}