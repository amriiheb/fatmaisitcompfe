module.exports = (app) => {
    const offres = require('../controllers/offre.controller.js');

    // Create a new Note
    app.post('/offres', offres.create);

    // Retrieve all Notes
    app.get('/offres', offres.findAll);

    // Retrieve a single Note with noteId
    app.get('/offres/:offreId', offres.findOne);

    // Update a Note with noteId
    app.put('/offres/:offreId', offres.update);

    // Delete a Note with noteId
    app.delete('/offres/:offreId', offres.delete);
}