module.exports = (app) => {
    const aviss = require('../controllers/avis.controller.js');

    // Create a new Note
    app.post('/aviss', aviss.create);

    // Retrieve all Notes
    app.get('/aviss', aviss.findAll);

    // Retrieve a single Note with noteId
    app.get('/aviss/:avisId', aviss.findOne);

    // Update a Note with noteId
    app.put('/aviss/:avisId', aviss.update);

    // Delete a Note with noteId
    app.delete('/aviss/:avisId', aviss.delete);
}
