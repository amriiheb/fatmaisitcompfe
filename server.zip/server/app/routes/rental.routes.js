module.exports = (app) => {
    const rentals = require('../controllers/rental.controller.js');


    app.post('/rentals', rentals.create);

    
    app.get('/rentals', rentals.findAll);

   
    app.get('/rentals/:rentalId', rentals.findOne);

    
    app.put('/rentals/:rentalId', rentals.update);

    
    app.delete('/rentals/:rentalId', rentals.delete);
}
