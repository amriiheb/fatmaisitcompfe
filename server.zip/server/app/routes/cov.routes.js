module.exports = (app) => {
    const covs = require('../controllers/cov.controller.js');


    app.post('/covs', covs.create);

    
    app.get('/covs', covs.findAll);

   
    app.get('/covs/:covId', covs.findOne);

    
    app.put('/covs/:covId', covs.update);

    
    app.delete('/covs/:covId', covs.delete);
}
