const Rental = require('../models/rental.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.email) {
        return res.status(400).send({
            message: "rental content can not be empty"
        });
    }

    // Create a Note
    const rental = new Rental({
        nom: req.body.nom || "Untitled rental", 
        prénom: req.body.prénom,
        mot_de_passe : req.body.mot_de_passe,
        email : req.body.email,
        adresse: req.body.adresse,
        téléphone : req.body.téléphone

        
    });

    // Save Note in the database
    rental.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the rental."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Rental.find()
    .then(rentals => {
        res.send(rentals);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving rental."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Rental.findById(req.params.rentalId)
    .then(rental => {
        if(!rental) {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });            
        }
        res.send(rental);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving rental with id " + req.params.rentalId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.username) {
        return res.status(400).send({
            message: "rental content can not be empty"
        });
    }

    // Find note and update it with the request body
    Rental.findByIdAndUpdate(req.params.rentalId, {
        nom: req.body.nom || "Untitled rental", 
        prénom: req.body.prénom,
        mot_de_passe : req.body.mot_de_passe,
        email : req.body.email,
        adresse: req.body.adresse,
        téléphone : req.body.téléphone

    }, {new: true})
    .then(rental => {
        if(!rental) {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });
        }
        res.send(rental);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });                
        }
        return res.status(500).send({
            message: "Error updating rental with id " + req.params.rentalId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Rental.findByIdAndRemove(req.params.rentalId)
    .then(rental => {
        if(!rental) {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });
        }
        res.send({message: "rental deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "rental not found with id " + req.params.rentalId
            });                
        }
        return res.status(500).send({
            message: "Could not delete rental with id " + req.params.rentalId
        });
    });
};
