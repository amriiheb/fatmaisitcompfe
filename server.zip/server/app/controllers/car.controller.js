const Car = require('../models/car.model.js');

// Create and Save a new car
exports.create = (req, res) => {
    // Validate request
    if(!req.body.mat) {
        return res.status(400).send({
            message: "car content can not be empty"
        });
    }

    // Create a car
    const car = new Car({
        mat: req.body.mat || "Untitled car", 
        nomv : req.body.nomv,
        marque: req.body.marque,
        desc : req.body.desc,
        kilo : req.body.kilo,
        trans : req.body.trans,
        nbdeplace : req.body.nbdeplace,
        bags : req.body.bags,
        energy : req.body.energy,
        features : req.body.features,
        image : req.body.image,
        prixparheure : req.body.prixparheure,
        prixparjour : req.body.prixparjour,
        prixparmois : req.body.prixparmois,
        iduser : req.body.iduser,
        nomuser : req.body.nomuser,
        etat:"refuser"
    });

    // Save car in the database
    car.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the car."
        });
    });
};

// Retrieve and return all car from the database.
exports.findAll = (req, res) => {
    Car.find()
    .then(cars => {
        res.send(cars);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving car."
        });
    });
};

// Find a single car with a car
exports.findOne = (req, res) => {
    Car.findById(req.params.carId)
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });            
        }
        res.send(car);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving car with id " + req.params.carId
        });
    });
};

// Update a car identified by the car in the request
exports.update = (req, res) => {
    /*// Validate Request
    if(!req.body.mat) {
        return res.status(400).send({
            message: "car content can not be empty"
        });
    }
*/
    // Find admin and update it with the request body
    Car.findByIdAndUpdate(req.params.carId, {

        etat:req.body.etat
    }, {new: true})
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });
        }
        res.send(car);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Error updating car with id " + req.params.carId
        });
    });
};

// Delete a car with the specified car in the request
exports.delete = (req, res) => {
    Car.findByIdAndRemove(req.params.carId)
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });
        }
        res.send({message: "car deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "car not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Could not delete car with id " + req.params.carId
        });
    });
};
