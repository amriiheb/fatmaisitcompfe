const Offre = require('../models/offre.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.mat) {
        return res.status(400).send({
            message: "offre content can not be empty"
        });
    }

    // Create a Note
    const offre = new Offre({
        mat: req.body.mat || "Untitled car",
        depart : req.body.depart,
        fin : req.body.fin, 
        nomv : req.body.nomv,
        marque: req.body.marque,
        nbdeplace : req.body.nbdeplace,
        bags : req.body.bags,
        features : req.body.features,
        image : req.body.image,
        heure : req.body.heure,
        datec : req.body.datec,
        prixvoyage : req.body.prixvoyage,
        iduser : req.body.iduser,
        nomuser : req.body.nomuser,
        etat:"refuser"
    });

    // Save Note in the database
    offre.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the offre."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Offre.find()
    .then(offres => {
        res.send(offres);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving offre."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Offre.findById(req.params.offreId)
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });            
        }
        res.send(offre);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving offre with id " + req.params.offreId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {


    // Find note and update it with the request body
    Offre.findByIdAndUpdate(req.params.offreId, {

        etat:req.body.etat
    }, {new: true})
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });
        }
        res.send(offre);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Error updating offre with id " + req.params.offreId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Offre.findByIdAndRemove(req.params.offreId)
    .then(offre => {
        if(!offre) {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });
        }
        res.send({message: "offre deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "offre not found with id " + req.params.offreId
            });                
        }
        return res.status(500).send({
            message: "Could not delete offre with id " + req.params.offreId
        });
    });
};
