const Cov = require('../models/cov.model.js');

// Create and Save a new Note
exports.create = (req, res) => {
    // Validate request
    if(!req.body.name) {
        return res.status(400).send({
            message: "cov content can not be empty"
        });
    }

    // Create a Note
    const cov = new Cov({
        name: req.body.name,
        idclient : req.body.idclient,
        idoffre : req.body.idoffre,
        etat : req.body.etat
    });

    // Save Note in the database
    cov.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the cov."
        });
    });
};

// Retrieve and return all notes from the database.
exports.findAll = (req, res) => {
    Cov.find()
    .then(covs => {
        res.send(covs);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving cov."
        });
    });
};

// Find a single note with a noteId
exports.findOne = (req, res) => {
    Cov.findById(req.params.covId)
    .then(cov => {
        if(!cov) {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });            
        }
        res.send(cov);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving cov with id " + req.params.covId
        });
    });
};

// Update a note identified by the noteId in the request
exports.update = (req, res) => {
    // Validate Request


    // Find note and update it with the request body
    Cov.findByIdAndUpdate(req.params.covId, {
        etat : req.body.etat

    }, {new: true})
    .then(cov => {
        if(!cov) {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });
        }
        res.send(cov);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });                
        }
        return res.status(500).send({
            message: "Error updating cov with id " + req.params.covId
        });
    });
};

// Delete a note with the specified noteId in the request
exports.delete = (req, res) => {
    Cov.findByIdAndRemove(req.params.covId)
    .then(cov => {
        if(!cov) {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });
        }
        res.send({message: "cov deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "cov not found with id " + req.params.covId
            });                
        }
        return res.status(500).send({
            message: "Could not delete cov with id " + req.params.covId
        });
    });
};
