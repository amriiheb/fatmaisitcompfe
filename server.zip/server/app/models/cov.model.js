const mongoose = require('mongoose');

const CovSchema = mongoose.Schema({
    name: String,
    idclient : String,
    idoffre : String,
    etat : String 
}, {
    timestamps: true
});

module.exports = mongoose.model('Cov', CovSchema);