const mongoose = require('mongoose');

const AdminSchema = mongoose.Schema({
        nom: {
            type: String,

            required: [true, 'The username is required'],
            unique: [true, 'The username is unique']

    },
       prénom: {
            type: String,
        
            required: [true, 'The username is required'],
            unique: [true, 'The username is unique']

    },
    email: {
            type: String,

            required: [true, 'The email is required'],
            unique: [true, 'The email is unique']

    },
    mot_de_passe: {
            type: String,
        
            required: [true, 'The password is required'],

           
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Admin', AdminSchema);