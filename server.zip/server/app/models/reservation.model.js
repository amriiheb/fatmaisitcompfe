const mongoose = require('mongoose');

const ReservationSchema = mongoose.Schema({
    name: String,
    idclient : String,
    idcar : String,
    dated : String,
    datef : String,
    heure : String,
    adresse : String,
    etat : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Reservation', ReservationSchema);