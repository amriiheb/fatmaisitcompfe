const mongoose = require('mongoose');

const CarSchema = mongoose.Schema({
        mat: String, 
        nomv : String,
        marque: String,
        desc : String,
        kilo : String,
        trans : String,
        nbdeplace : String,
        bags : String,
        energy : String,
        features : String,
        image : String,
        prixparheure : String,
        prixparjour : String,
        prixparmois : String,
        iduser : String,
        nomuser : String,
        etat :String
}, {
    timestamps: true
});

module.exports = mongoose.model('Car', CarSchema);