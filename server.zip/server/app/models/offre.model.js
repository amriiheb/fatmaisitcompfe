const mongoose = require('mongoose');

const OffreSchema = mongoose.Schema({
        mat: String, 
        depart : String,
        fin : String,
        nomv : String,
        marque: String,
        nbdeplace : String,
        bags : String,
        features : String,
        image : String,
        prixvoyage : String,
        heure : String,
        datec  : String,
        iduser : String,
        nomuser : String,
        etat:String
}, {
    timestamps: true
});

module.exports = mongoose.model('Offre', OffreSchema);