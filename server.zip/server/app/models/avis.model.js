const mongoose = require('mongoose');

const AvisSchema = mongoose.Schema({
    idoffre: {
            type: String,
        
            required: [true, 'The username is required'],
         
           
    },
        idclient: {
            type: String,
        
            required: [true, 'The username is required'],
         
           
    },
    nomclient : String,
        titre: {
            type: String,
        
            required: [true, 'The username is required'],
         
           
    },
   
    contenu : {
            type: String,
        
            required: [true, 'The username is required'],
         
           
    }
    
}, {
    timestamps: true
});

module.exports = mongoose.model('Avis', AvisSchema);